//import { fibonacci } from "fibonnaci";

const { fibonacci } = require("./fibonacci");
let arg = fibonacci(6);
console.log(arg);
